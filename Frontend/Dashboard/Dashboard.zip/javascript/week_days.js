const state = {
    currentDate: new Date(),
    selectedYear: new Date().getFullYear(),
    selectedMonth: new Date().getMonth(),
  };

  window.addEventListener('DOMContentLoaded', (event) => {
    populateYearSelect();
    populateMonthSelect();
    renderWeekdays();
    attachEventListeners();
  });

  function populateYearSelect() {
    const yearSelect = document.getElementById('year-select');
    const currentYear = state.selectedYear;
    for (let i = currentYear - 5; i <= currentYear + 5; i++) {
      const option = document.createElement('option');
      option.value = i;
      option.innerText = i;
      yearSelect.appendChild(option);
    }
    yearSelect.value = currentYear;
  }

  function populateMonthSelect() {
    const monthSelect = document.getElementById('month-select');
    const months = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    months.forEach((month, index) => {
      const option = document.createElement('option');
      option.value = index;
      option.innerText = month;
      monthSelect.appendChild(option);
    });
    monthSelect.value = state.selectedMonth;
  }

  function attachEventListeners() {
    const prevWeekButton = document.getElementById('prev-week');
    const nextWeekButton = document.getElementById('next-week');
    const yearSelect = document.getElementById('year-select');
    const monthSelect = document.getElementById('month-select');

    prevWeekButton.addEventListener('click', () => navigateWeeks(-1));
    nextWeekButton.addEventListener('click', () => navigateWeeks(1));
    yearSelect.addEventListener('change', (e) => {
      state.selectedYear = parseInt(e.target.value);
      resetToFirstWeekOfMonth(state.selectedYear, state.selectedMonth);
    });
    monthSelect.addEventListener('change', (e) => {
      state.selectedMonth = parseInt(e.target.value);
      resetToFirstWeekOfMonth(state.selectedYear, state.selectedMonth);
    });
  }

  function navigateWeeks(direction) {
    const startOfWeek = getWeekStart(state.currentDate);
    startOfWeek.setDate(startOfWeek.getDate() + direction * 7);

    if (isWeekWithinSelectedMonthAndYear(startOfWeek, state.selectedYear, state.selectedMonth)) {
      state.currentDate = startOfWeek;
      renderWeekdays();
    }
  }

  function isWeekWithinSelectedMonthAndYear(weekStart, year, month) {
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekStart.getDate() + 6);

    return (weekStart.getFullYear() === year && weekStart.getMonth() === month) ||
      (weekEnd.getFullYear() === year && weekEnd.getMonth() === month);
  }

  function resetToFirstWeekOfMonth(year, month) {
    state.currentDate = new Date(year, month, 1);
    renderWeekdays();
  }

  function renderWeekdays() {
    const weekdaysContainer = document.getElementById('weekdays-container');
    weekdaysContainer.innerHTML = '';

    state.selectedYear = state.currentDate.getFullYear();
    state.selectedMonth = state.currentDate.getMonth();
    updateSelectInputs(state.selectedYear, state.selectedMonth);

    const weekStart = getWeekStart(state.currentDate);
    for (let i = 1; i < 7; i++) {
      const date = new Date(weekStart);
      date.setDate(date.getDate() + i);

      const dayDiv = document.createElement('div');
      dayDiv.className = 'day-name';
      dayDiv.innerText = date.toLocaleString('default', { weekday: 'short' });

      const dateDiv = document.createElement('div');
      dateDiv.className = 'date-number';
      dateDiv.innerText = date.getDate();

      const dayElement = document.createElement('div');
      dayElement.className = 'weekday';
      dayElement.appendChild(dayDiv);
      dayElement.appendChild(dateDiv);

      weekdaysContainer.appendChild(dayElement);
    }


    clearDots();

    placeDot(14, '10:00'); 
  }



  function getWeekStart(date) {
    const weekStart = new Date(date);
    weekStart.setDate(weekStart.getDate() - weekStart.getDay());
    return weekStart;
  }
  function clearDots() {
document.querySelectorAll('.dot').forEach(dot => dot.remove());
}
  function updateSelectInputs(selectedYear, selectedMonth) {
    const yearSelect = document.getElementById('year-select');
    const monthSelect = document.getElementById('month-select');
    yearSelect.value = selectedYear;
    monthSelect.value = selectedMonth;
  }

  function placeDot(date, time) {
const weekdays = document.querySelectorAll('.weekday');
clearDots();

let targetDayElement;
weekdays.forEach((dayElement, index) => {
  const day = dayElement.querySelector('.date-number');
  if (day && parseInt(day.textContent) === date) {
    targetDayElement = dayElement;
  }
});

if (targetDayElement) {
  const timeContainer = document.querySelector(`.time-slot[data-time="${time}"]`);
  if (timeContainer) {
    const dot = document.createElement('span');
    dot.className = 'dot';
    dot.style.position = 'absolute';
    dot.style.left = `${targetDayElement.offsetLeft + targetDayElement.offsetWidth / 2 - dot.offsetWidth / 2}px`;
    timeContainer.appendChild(dot);
  }
}
}